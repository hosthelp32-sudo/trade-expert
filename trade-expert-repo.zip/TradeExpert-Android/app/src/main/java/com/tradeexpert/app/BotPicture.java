package com.tradeexpert.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** The bot picture, shared by the display and the console card. */
final class BotPicture {

    static volatile Bitmap bitmap = null;
    private static String current = "";

    private BotPicture() {}

    static void load(final String img) {
        if (img == null || img.isEmpty() || img.equals(current)) return;
        current = img;
        if (img.startsWith("data:image")) {
            try {
                byte[] b = Base64.decode(img.substring(img.indexOf(',') + 1), Base64.DEFAULT);
                done(BitmapFactory.decodeByteArray(b, 0, b.length));
            } catch (Exception ignored) {
            }
            return;
        }
        if (!img.startsWith("http")) return;
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(img).openConnection();
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                try (InputStream in = c.getInputStream()) {
                    done(BitmapFactory.decodeStream(in));
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    private static void done(final Bitmap bm) {
        if (bm == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            bitmap = bm;
            BubbleService.onBotPicture();
        });
    }
}
