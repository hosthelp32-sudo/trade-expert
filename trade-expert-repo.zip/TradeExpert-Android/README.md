# Trade Expert (Android)

The Trade Expert app. It opens the platform (`/ea-app/activate`) from the app's own copy of the site, stored in `app/src/main/assets/app/index.html`.

## Build
GitHub builds the APK by itself (see `.github/workflows/build-apk.yml`).
Upload this zip to the repo main folder, then download the APK from Releases.

## Files
- `app/src/main/java/com/tradeexpert/app/MainActivity.java`: the screen (WebView).
- `app/src/main/AndroidManifest.xml`: app settings (internet permission only).
- `app/build.gradle`: Android build settings (SDK 34, no extra libraries).
- `app/src/main/assets/app/index.html`: the platform.
